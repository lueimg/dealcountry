(function($) {
	
	$(document).ready(function() {
		console.log('working');
	});
	
	
	
})(jQuery);;
