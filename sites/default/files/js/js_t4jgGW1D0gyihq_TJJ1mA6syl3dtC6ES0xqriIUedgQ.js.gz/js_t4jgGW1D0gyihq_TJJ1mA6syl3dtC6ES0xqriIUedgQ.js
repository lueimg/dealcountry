/**
 * Provides the ability to fix a html block to a position on the page when the
 * browser is scroled.
 *
 * This code is based on tableheader.js
 */
(function ($) {

Drupal.blockFloatStack = function() {
  if( typeof Drupal.blockFloatStack.blocks == 'undefined' ) {
    Drupal.blockFloatStack.blocks = [];
  }
  return Drupal.blockFloatStack.blocks;
}

/**
 * Attaches the floating_block behavior.
 */
Drupal.behaviors.blockFloat = {
  attach: function (context) {

    var settings = Drupal.settings.floating_block;

    // This breaks in anything less than IE 7. Prevent it from running.
    if ($.browser.msie && parseInt($.browser.version, 10) < 7) {
      return;
    }

    // If this behaviour is being called as part of processing an ajax callback.
    if (jQuery.isFunction(context.parent)) {
      context = context.parent();
    }

    // Cycle through all of the blocks we want to float.
    $.each(settings, function (selector, setting) {
      // The format of a select is [float]|[container] where:
      // [float] is the jQuery selector of thing you want to stay on screen
      // [container] is the jQuery selector of container that defines a boundary
      // not to float outside of.
      $(selector.toString() + ':not(.blockFloat-processed)', context).each(function (j, block) {
        // Store information about the block to float.
        var blockInfo = [];
        blockInfo.original_css = [];
        blockInfo.original_css.left = Drupal.blockFloatCleanCSSValue($(block).css('left'));
        blockInfo.original_css.top = Drupal.blockFloatCleanCSSValue($(block).css('top'));
        blockInfo.original_css.position = $(block).css("position");
        blockInfo.floating = false;
        blockInfo.reset = true;
        blockInfo.original_identifier = 'blockFloat-' +  Drupal.blockFloatStack().length;

        // Store the selector for the container if it exists.
        if (setting.container && $(setting.container.toString()).length > 0) {
          blockInfo.container = setting.container;
        }

        if (setting.padding_top) {
          blockInfo.padding_top = setting.padding_top;
        }
        else {
          blockInfo.padding_top = 0;
        }

        if (setting.padding_bottom) {
          blockInfo.padding_bottom = setting.padding_bottom;
        }
        else {
          blockInfo.padding_bottom = 0;
        }

        // Fix the width of the block as often a block will be 100% of it's
        // container. This ensures that when it's floated it will keep it's
        // original width. There is no point using .css('width') as this will
        // return the computed value so we might as well just set it.
        $(block).width($(block).width());

        // Add class to block to indicate that we're done and give
        // Drupal.blockFloatTracker a certain way to identify the block.
        $(block).addClass('blockFloat-processed ' + blockInfo.original_identifier);

        // If the page loaded has already been scrolled calling
        // Drupal.blockFloatTracker will float the block if necessary.
        Drupal.blockFloatTracker(blockInfo);

        // Store the block in the floating_blocks array.
        Drupal.blockFloatStack().push(blockInfo);
      });
    });
  }
}

/**
 * Function that calculates whether or not the block should be floated.
 */
Drupal.blockFloatTracker = function (blockInfo) {
  // Save positioning data.
  var scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
  var block = $('.' + blockInfo.original_identifier);
  if (block.length == 0) {
    // The floated block must have been removed from the page - do nothing.
    return;
  }

  // (Re)calculate some values if necessary.
  if (blockInfo.scrollHeight != scrollHeight || blockInfo.reset) {
    if (blockInfo.reset) {
      // Reset block so we can calculate new offset.
      Drupal.blockFloatResetPosition(block, blockInfo);
      blockInfo.original_offset = $(block).offset();

      // Reset completed - set value so we don't do unnecessary resets.
      blockInfo.reset = false;
    }

    // Save the scrollHeight - if this changes we will need to recalculate.
    blockInfo.scrollHeight = scrollHeight;
    // The minimum offset is always defined by the blocks starting position.
    blockInfo.minOffset = blockInfo.original_offset.top - blockInfo.padding_top;

    // Calulate the maxOffset which depends on whether or not a container is
    // defined. Otherwise use the scrollHeight.
    if (blockInfo.container) {
      blockInfo.maxOffset = $(blockInfo.container).height() + $(blockInfo.container).offset().top - blockInfo.padding_bottom;
    }
    else {
      blockInfo.maxOffset = scrollHeight;
    }
  }

  // Track positioning relative to the viewport and set position.
  var vScroll = (document.documentElement.scrollTop || document.body.scrollTop);
  if (vScroll > blockInfo.minOffset) {
    var topPosition = blockInfo.padding_top;
    // Block height can change if there a collapsible fields etc... inside the
    // block so recalculate everytime we are floating the block.
    var blockHeight = block.height();
    // Don't let the bottom of the block go beneath maxOffset.
    if ((vScroll + blockHeight) > blockInfo.maxOffset) {
      // At this point topPosition will become a negative number to keep the
      // block from going out of the defined container.
      topPosition = blockInfo.maxOffset - vScroll - blockHeight;
    }

    block.css({
      left:  blockInfo.original_offset.left + 'px',
      position: 'fixed',
      top: topPosition + 'px'
    }).addClass('floating-block-active');

    blockInfo.floating = true;
  }
  else {
    // Put the block back in it's original postion
    Drupal.blockFloatResetPosition(block, blockInfo);
  }
}

/**
 * Resets the position of a floated block back to non floated position.
 */
Drupal.blockFloatResetPosition = function (block, blockInfo) {
  if (blockInfo.floating) {
    block.css({
      left: blockInfo.original_css.left,
      position: blockInfo.original_css.position,
      top: blockInfo.original_css.top
    }).removeClass('floating-block-active');
    blockInfo.floating = false;
  }
}

/**
 * If the css value is 0px for top and left then it is not actually set using
 * CSS - this will be the computed value. Setting to a blank string will ensure
 * that when Drupal.blockFloatResetPosition is called these css value will be
 * unset.
 */
Drupal.blockFloatCleanCSSValue = function (cssvalue) {
  if (cssvalue == '0px') {
    cssvalue = '';
  }
  return cssvalue;
}

/**
 * Callback to be added to the scroll event. Each time the user scrolls this
 * function will be called.
 */
Drupal.blockFloatOnScroll = function() {
  $(Drupal.blockFloatStack()).each(function () {
    Drupal.blockFloatTracker(this);
  });
};

/**
 * Callback to be added to the resize event. Each time the user resizes the
 * this window this function will be called. A timeout is used to prevent
 * this function from causing a slow down during resizing.
 */
Drupal.blockFloatWindowResize = function() {
  if( typeof Drupal.blockFloatWindowResize.timer == 'undefined' ) {
    Drupal.blockFloatWindowResize.timer = false;
  }
  // Ensure minimum time between adjustments.
  if (Drupal.blockFloatWindowResize.timer) {
    return;
  }
  Drupal.blockFloatWindowResize.timer = setTimeout(function () {
    $(Drupal.blockFloatStack()).each(function () {
      this.reset = true;
      Drupal.blockFloatTracker(this);
    });
    // Reset timer
    Drupal.blockFloatWindowResize.timer = false;
  }, 250);
};

/**
 * Attach callbacks to resize and scroll events. Add a class to the body to
 * prevent doing this multiple times.
 */
if (!$('body').hasClass('blockFloat-processed')) {
  $('body').addClass('blockFloat-processed');
  $(window).scroll(Drupal.blockFloatOnScroll);
  $(document.documentElement).scroll(Drupal.blockFloatOnScroll);
  $(window).resize(Drupal.blockFloatWindowResize);
}

})(jQuery);
;
(function ($) {
	$(document).ready(function() {
		/*if($('.view-deals-front').length > 0) {
			$(".view-deals-front").addClass("option-list");
		}*/
		if($('.social-tooltip').length > 0) {	
	    	$('.social-tooltip').tooltip();	    
		}
		
		if($('.node-type-deal .group-deal-map .panel-title').length > 0 && $('.node-type-deal .group-deal-map .views-field-field-address span.fn').length > 0) {	
	    	$('.node-type-deal .group-deal-map .panel-title').text('About ' + $('.node-type-deal .group-deal-map .views-field-field-address span.fn').text());	    
		}
		if($('#edit-sort-bef-combine').length > 0) {	
		    $('#edit-sort-bef-combine').selectpicker();
		}
		if($('#edit-field-deal-categories-tid').length > 0) {	
		    $('#edit-field-deal-categories-tid').selectpicker();
		}
		$('input:radio[name="options-deals"]').change(
		    function(){		
	            limadot_asign_list($(this).val());	            	
		});	
		if ($('.view-deals-front.view-display-id-page').length > 0 || $('.view-deals-front.view-display-id-page_1').length > 0 || $('.view-deals-front.view-display-id-page_2').length > 0) {
			if(Drupal.settings.limadot_general.option_list_selected == "grid") {
				limadot_asign_list("grid");	
			} else {
				limadot_asign_list("list");			
			}		
		}
	});
	
	Drupal.behaviors.limadot_reload_colorbox = {
		attach : function(context, settings) {
			if($('#colorbox .webform-confirmation').length > 0) {
				$.colorbox.resize();
			}
		}
	}
	
	Drupal.behaviors.limadot_reload_masonry = {
		attach : function(context, settings) {
			$(window).bind("resize", function() {
				if ($('.view-deals-front').length > 0) {
					$('.view-deals-front .view-content').masonry('reload');
				}
			});
		}
	}
	
	function limadot_asign_list(type) {
		if(type == "grid") {
			$(".view-deals-front").removeClass("option-list");
			$(".region-content").parent().removeClass("col-sm-9");
			$(".region-content").parent().addClass("col-sm-12");
			$(".region-sidebar-second").parent().hide();
			$('.view-deals-front .view-content').masonry('reload');
			$('.view-most-popular-deals .view-content').masonry('reload');
			$('input#option-grid').parent().addClass('active');
			$('input#option-list').parent().removeClass('active');
			/*$("#page-header").append($(".col-sm-3.mini").html());
			$(".col-sm-3.mini").empty();*/
			$(".region-sidebar-second-top").prependTo($("#page-header"));
			Drupal.settings.limadot_general.option_list_selected = "grid";
		} else {
			$(".view-deals-front").addClass("option-list");
			$(".region-content").parent().removeClass("col-sm-12");
			$(".region-content").parent().addClass("col-sm-9");
			$(".region-sidebar-second").parent().show();
			$('.view-deals-front .view-content').masonry('reload');
			$('.view-most-popular-deals .view-content').masonry('reload');
			$('input#option-list').parent().addClass('active');
			$('input#option-grid').parent().removeClass('active');
			/*$(".col-sm-3.mini").append($("#page-header").html());
			$("#page-header").empty();*/
			$(".region-sidebar-second-top").prependTo($(".col-sm-3.mini"));
			Drupal.settings.limadot_general.option_list_selected = "list";
		}
	}
	
})(jQuery);;
(function ($) {

/**
 * Attaches double-click behavior to toggle full path of Krumo elements.
 */
Drupal.behaviors.devel = {
  attach: function (context, settings) {

    // Add hint to footnote
    $('.krumo-footnote .krumo-call').before('<img style="vertical-align: middle;" title="Click to expand. Double-click to show path." src="' + Drupal.settings.basePath + 'misc/help.png"/>');

    var krumo_name = [];
    var krumo_type = [];

    function krumo_traverse(el) {
      krumo_name.push($(el).html());
      krumo_type.push($(el).siblings('em').html().match(/\w*/)[0]);

      if ($(el).closest('.krumo-nest').length > 0) {
        krumo_traverse($(el).closest('.krumo-nest').prev().find('.krumo-name'));
      }
    }

    $('.krumo-child > div:first-child', context).dblclick(
      function(e) {
        if ($(this).find('> .krumo-php-path').length > 0) {
          // Remove path if shown.
          $(this).find('> .krumo-php-path').remove();
        }
        else {
          // Get elements.
          krumo_traverse($(this).find('> a.krumo-name'));

          // Create path.
          var krumo_path_string = '';
          for (var i = krumo_name.length - 1; i >= 0; --i) {
            // Start element.
            if ((krumo_name.length - 1) == i)
              krumo_path_string += '$' + krumo_name[i];

            if (typeof krumo_name[(i-1)] !== 'undefined') {
              if (krumo_type[i] == 'Array') {
                krumo_path_string += "[";
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += krumo_name[(i-1)];
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += "]";
              }
              if (krumo_type[i] == 'Object')
                krumo_path_string += '->' + krumo_name[(i-1)];
            }
          }
          $(this).append('<div class="krumo-php-path" style="font-family: Courier, monospace; font-weight: bold;">' + krumo_path_string + '</div>');

          // Reset arrays.
          krumo_name = [];
          krumo_type = [];
        }
      }
    );
  }
};

})(jQuery);
;

/**
 * Cookie plugin 1.0
 *
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */
jQuery.cookie=function(b,j,m){if(typeof j!="undefined"){m=m||{};if(j===null){j="";m.expires=-1}var e="";if(m.expires&&(typeof m.expires=="number"||m.expires.toUTCString)){var f;if(typeof m.expires=="number"){f=new Date();f.setTime(f.getTime()+(m.expires*24*60*60*1000))}else{f=m.expires}e="; expires="+f.toUTCString()}var l=m.path?"; path="+(m.path):"";var g=m.domain?"; domain="+(m.domain):"";var a=m.secure?"; secure":"";document.cookie=[b,"=",encodeURIComponent(j),e,l,g,a].join("")}else{var d=null;if(document.cookie&&document.cookie!=""){var k=document.cookie.split(";");for(var h=0;h<k.length;h++){var c=jQuery.trim(k[h]);if(c.substring(0,b.length+1)==(b+"=")){d=decodeURIComponent(c.substring(b.length+1));break}}}return d}};
;
(function ($) {

Drupal.ModuleFilter = {};

Drupal.ModuleFilter.explode = function(string) {
  var queryArray = string.match(/([a-zA-Z]+\:(\w+|"[^"]+")*)|\w+|"[^"]+"/g);
  if (!queryArray) {
    queryArray = new Array();
  }
  var i = queryArray.length;
  while (i--) {
    queryArray[i] = queryArray[i].replace(/"/g, "");
  }
  return queryArray;
};

Drupal.ModuleFilter.getState = function(key) {
  if (!Drupal.ModuleFilter.state) {
    Drupal.ModuleFilter.state = {};
    var cookie = $.cookie('DrupalModuleFilter');
    var query = cookie ? cookie.split('&') : [];
    if (query) {
      for (var i in query) {
        // Extra check to avoid js errors in Chrome, IE and Safari when
        // combined with JS like twitter's widget.js.
        // See http://drupal.org/node/798764.
        if (typeof(query[i]) == 'string' && query[i].indexOf('=') != -1) {
          var values = query[i].split('=');
          if (values.length === 2) {
            Drupal.ModuleFilter.state[values[0]] = values[1];
          }
        }
      }
    }
  }
  return Drupal.ModuleFilter.state[key] ? Drupal.ModuleFilter.state[key] : false;
};

Drupal.ModuleFilter.setState = function(key, value) {
  var existing = Drupal.ModuleFilter.getState(key);
  if (existing != value) {
    Drupal.ModuleFilter.state[key] = value;
    var query = [];
    for (var i in Drupal.ModuleFilter.state) {
      query.push(i + '=' + Drupal.ModuleFilter.state[i]);
    }
    $.cookie('DrupalModuleFilter', query.join('&'), { expires: 7, path: '/' });
  }
};

Drupal.ModuleFilter.Filter = function(element, selector, options) {
  var self = this;

  this.element = element;
  this.text = $(this.element).val();

  this.settings = Drupal.settings.moduleFilter;

  this.selector = selector;

  this.options = $.extend({
    delay: 500,
    striping: false,
    childSelector: null,
    empty: Drupal.t('No results'),
    rules: new Array()
  }, options);
  if (this.options.wrapper == undefined) {
    this.options.wrapper = $(self.selector).parent();
  }

  // Add clear button.
  this.element.after('<div class="module-filter-clear"><a href="#" class="js-hide">' + Drupal.t('clear') + '</a></div>');
  if (this.text) {
    $('.module-filter-clear a', this.element.parent()).removeClass('js-hide');
  }
  $('.module-filter-clear a', this.element.parent()).click(function() {
    self.element.val('');
    self.text = '';
    delete self.queries;
    self.applyFilter();
    self.element.focus();
    $(this).addClass('js-hide');
    return false;
  });

  this.updateQueries = function() {
    var queryStrings = Drupal.ModuleFilter.explode(self.text);

    self.queries = new Array();
    for (var i in queryStrings) {
      var query = { operator: 'text', string: queryStrings[i] };

      if (self.operators != undefined) {
        // Check if an operator is possibly used.
        if (queryStrings[i].indexOf(':') > 0) {
          // Determine operator used.
          var args = queryStrings[i].split(':', 2);
          var operator = args.shift();
          if (self.operators[operator] != undefined) {
            query.operator = operator;
            query.string = args.shift();
          }
        }
      }

      query.string = query.string.toLowerCase();

      self.queries.push(query);
    }

    if (self.queries.length <= 0) {
      // Add a blank string query.
      self.queries.push({ operator: 'text', string: '' });
    }
  };

  this.applyFilter = function() {
    self.results = new Array();

    self.updateQueries();

    if (self.index == undefined) {
      self.buildIndex();
    }

    self.element.trigger('moduleFilter:start');

    $.each(self.index, function(key, item) {
      var $item = item.element;

      for (var i in self.queries) {
        var query = self.queries[i];
        if (query.operator == 'text') {
          if (item.text.indexOf(query.string) < 0) {
            continue;
          }
        }
        else {
          var func = self.operators[query.operator];
          if (!(func(query.string, self, item))) {
            continue;
          }
        }

        var rulesResult = self.processRules(item);
        if (rulesResult !== false) {
          return true;
        }
      }

      $item.addClass('js-hide');
    });

    self.element.trigger('moduleFilter:finish', { results: self.results });

    if (self.options.striping) {
      self.stripe();
    }

    if (self.results.length > 0) {
      self.options.wrapper.find('.module-filter-no-results').remove();
    }
    else {
      if (!self.options.wrapper.find('.module-filter-no-results').length) {
        self.options.wrapper.append($('<p class="module-filter-no-results"/>').text(self.options.empty));
      };
    }
  };

  self.element.keyup(function(e) {
    switch (e.which) {
      case 13:
        if (self.timeOut) {
          clearTimeout(self.timeOut);
        }
        self.applyFilter();
        break;
      default:
        if (self.text != $(this).val()) {
          if (self.timeOut) {
            clearTimeout(self.timeOut);
          }

          self.text = $(this).val();

          if (self.text) {
            self.element.parent().find('.module-filter-clear a').removeClass('js-hide');
          }
          else {
            self.element.parent().find('.module-filter-clear a').addClass('js-hide');
          }

          self.element.trigger('moduleFilter:keyup');

          self.timeOut = setTimeout(self.applyFilter, self.options.delay);
        }
        break;
    }
  });

  self.element.keypress(function(e) {
    if (e.which == 13) e.preventDefault();
  });
};

Drupal.ModuleFilter.Filter.prototype.buildIndex = function() {
  var self = this;
  var index = new Array();
  $(this.selector).each(function(i) {
    var text = (self.options.childSelector) ? $(self.options.childSelector, this).text() : $(this).text();
    var item = {
      key: i,
      element: $(this),
      text: text.toLowerCase()
    };
    for (var j in self.options.buildIndex) {
      var func = self.options.buildIndex[j];
      item = $.extend(func(self, item), item);
    }
    $(this).data('indexKey', i);
    index.push(item);
    delete item;
  });
  this.index = index;
};

Drupal.ModuleFilter.Filter.prototype.processRules = function(item) {
  var self = this;
  var $item = item.element;
  var rulesResult = true;
  if (self.options.rules.length > 0) {
    for (var i in self.options.rules) {
      var func = self.options.rules[i];
      rulesResult = func(self, item);
      if (rulesResult === false) {
        break;
      }
    }
  }
  if (rulesResult !== false) {
    $item.removeClass('js-hide');
    self.results.push(item);
  }
  return rulesResult;
};

Drupal.ModuleFilter.Filter.prototype.stripe = function() {
  var self = this;
  var flip = { even: 'odd', odd: 'even' };
  var stripe = 'odd';

  $.each(self.index, function(key, item) {
    if (!item.element.hasClass('js-hide')) {
      item.element.removeClass('odd even')
        .addClass(stripe);
      stripe = flip[stripe];
    }
  });
};

$.fn.moduleFilter = function(selector, options) {
  var filterInput = this;
  filterInput.parents('.module-filter-inputs-wrapper').show();
  if (Drupal.settings.moduleFilter.setFocus) {
    filterInput.focus();
  }
  filterInput.data('moduleFilter', new Drupal.ModuleFilter.Filter(this, selector, options));
};

})(jQuery);
;
(function($) {

Drupal.behaviors.moduleFilterUpdateStatus = {
  attach: function(context) {
    $('#module-filter-update-status-form').once('update-status', function() {
      var filterInput = $('input[name="module_filter[name]"]', context);
      filterInput.moduleFilter('table.update > tbody > tr', {
        wrapper: $('table.update:first').parent(),
        delay: 300,
        childSelector: 'div.project a',
        rules: [
          function(moduleFilter, item) {
            switch (moduleFilter.options.show) {
              case 'all':
                return true;
              case 'updates':
                if (item.state == 'warning' || item.state == 'error') {
                  return true;
                }
                break;
              case 'security':
                if (item.state == 'error') {
                  return true;
                }
                break;
              case 'ignore':
                if (item.state == 'ignored') {
                  return true;
                }
                break;
              case 'unknown':
                if (item.state == 'unknown') {
                  return true;
                }
                break;
            }
            return false;
          }
        ],
        buildIndex: [
          function(moduleFilter, item) {
            if ($('.version-status', item.element).text() == Drupal.t('Ignored from settings')) {
              item.state = 'ignored';
              return item;
            }
            if (item.element.is('.ok')) {
              item.state = 'ok';
            }
            else if (item.element.is('.warning')) {
              item.state = 'warning';
            }
            else if (item.element.is('.error')) {
              item.state = 'error';
            }
            else if (item.element.is('.unknown')) {
              item.state = 'unknown';
            }
            return item;
          }
        ],
        show: $('#edit-module-filter-show input[name="module_filter[show]"]', context).val()
      });

      var moduleFilter = filterInput.data('moduleFilter');

      if (Drupal.settings.moduleFilter.rememberUpdateState) {
        var updateShow = Drupal.ModuleFilter.getState('updateShow');
        if (updateShow) {
          moduleFilter.options.show = updateShow;
          $('#edit-module-filter-show input[name="module_filter[show]"][value="' + updateShow + '"]', context).click();
        }
      }

      $('#edit-module-filter-show input[name="module_filter[show]"]', context).change(function() {
        moduleFilter.options.show = $(this).val();
        Drupal.ModuleFilter.setState('updateShow', moduleFilter.options.show);
        moduleFilter.applyFilter();
      });

      moduleFilter.element.bind('moduleFilter:start', function() {
        $('table.update').each(function() {
          $(this).show().prev('h3').show();
        });
      });

      moduleFilter.element.bind('moduleFilter:finish', function(e, data) {
        $('table.update').each(function() {
          var $table = $(this);
          if ($('tbody tr', $(this)).filter(':visible').length == 0) {
            $table.hide().prev('h3').hide();
          }
        });
      });

      moduleFilter.element.bind('moduleFilter:keyup', function() {
        if (moduleFilter.clearOffset == undefined) {
          moduleFilter.inputWidth = filterInput.width();
          moduleFilter.clearOffset = moduleFilter.element.parent().find('.module-filter-clear a').width();
        }
        if (moduleFilter.text) {
          filterInput.width(moduleFilter.inputWidth - moduleFilter.clearOffset - 5).parent().css('margin-right', moduleFilter.clearOffset + 5);
        }
        else {
          filterInput.width(moduleFilter.inputWidth).parent().css('margin-right', 0);
        }
      });

      moduleFilter.element.parent().find('.module-filter-clear a').click(function() {
        filterInput.width(moduleFilter.inputWidth).parent().css('margin-right', 0);
      });

      moduleFilter.applyFilter();
    });
  }
};

})(jQuery);
;
(function ($) {

/**
 * A progressbar object. Initialized with the given id. Must be inserted into
 * the DOM afterwards through progressBar.element.
 *
 * method is the function which will perform the HTTP request to get the
 * progress bar state. Either "GET" or "POST".
 *
 * e.g. pb = new progressBar('myProgressBar');
 *      some_element.appendChild(pb.element);
 */
Drupal.progressBar = function (id, updateCallback, method, errorCallback) {
  var pb = this;
  this.id = id;
  this.method = method || 'GET';
  this.updateCallback = updateCallback;
  this.errorCallback = errorCallback;

  // The WAI-ARIA setting aria-live="polite" will announce changes after users
  // have completed their current activity and not interrupt the screen reader.
  this.element = $('<div class="progress" aria-live="polite"></div>').attr('id', id);
  this.element.html('<div class="bar"><div class="filled"></div></div>' +
                    '<div class="percentage"></div>' +
                    '<div class="message">&nbsp;</div>');
};

/**
 * Set the percentage and status message for the progressbar.
 */
Drupal.progressBar.prototype.setProgress = function (percentage, message) {
  if (percentage >= 0 && percentage <= 100) {
    $('div.filled', this.element).css('width', percentage + '%');
    $('div.percentage', this.element).html(percentage + '%');
  }
  $('div.message', this.element).html(message);
  if (this.updateCallback) {
    this.updateCallback(percentage, message, this);
  }
};

/**
 * Start monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.startMonitoring = function (uri, delay) {
  this.delay = delay;
  this.uri = uri;
  this.sendPing();
};

/**
 * Stop monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.stopMonitoring = function () {
  clearTimeout(this.timer);
  // This allows monitoring to be stopped from within the callback.
  this.uri = null;
};

/**
 * Request progress data from server.
 */
Drupal.progressBar.prototype.sendPing = function () {
  if (this.timer) {
    clearTimeout(this.timer);
  }
  if (this.uri) {
    var pb = this;
    // When doing a post request, you need non-null data. Otherwise a
    // HTTP 411 or HTTP 406 (with Apache mod_security) error may result.
    $.ajax({
      type: this.method,
      url: this.uri,
      data: '',
      dataType: 'json',
      success: function (progress) {
        // Display errors.
        if (progress.status == 0) {
          pb.displayError(progress.data);
          return;
        }
        // Update display.
        pb.setProgress(progress.percentage, progress.message);
        // Schedule next timer.
        pb.timer = setTimeout(function () { pb.sendPing(); }, pb.delay);
      },
      error: function (xmlhttp) {
        pb.displayError(Drupal.ajaxError(xmlhttp, pb.uri));
      }
    });
  }
};

/**
 * Display errors on the page.
 */
Drupal.progressBar.prototype.displayError = function (string) {
  var error = $('<div class="messages error"></div>').html(string);
  $(this.element).before(error).hide();

  if (this.errorCallback) {
    this.errorCallback(this);
  }
};

})(jQuery);
;
(function ($) {
    Drupal.behaviors.colorboxNode = {
        // Lets find our class name and change our URL to
        // our defined menu path to open in a colorbox modal.
        attach: function (context, settings) {
            $('.colorbox-node', context).once('init-colorbox-node-processed', function () {
                $(this).colorboxNode({'launch': false});
            });

            // When using contextual links and clicking from within the colorbox
            // we need to close down colorbox when opening the built in overlay.
            $('ul.contextual-links a', context).once('colorboxNodeContextual').click(function () {
                $.colorbox.close();
            });
        }
    };

    // Bind our colorbox node functionality to an anchor
    $.fn.colorboxNode = function (options) {
        var settings = {
            'launch': true
        };

        $.extend(settings, options);

        var href = $(this).attr('data-href');
        if (typeof href == 'undefined' || href == false) {
            href = $(this).attr('href');
        }
        // Create an element so we can parse our a URL no matter if its internal or external.
        var parse = document.createElement('a');
        parse.href = href;
        // Lets add our colorbox link after the base path if necessary.
        var base_path = Drupal.settings.basePath;
        var pathname = parse.pathname;

        // Lets check to see if the pathname has a forward slash.
        // This problem happens in IE7/IE8
        if (pathname.charAt(0) != '/') {
            pathname = '/' + parse.pathname;
        }

        if (base_path != '/') {
            var link = pathname.replace(base_path, base_path + 'colorbox/') + parse.search;
        } else {
            var link = base_path + 'colorbox' + pathname + parse.search;
        }

        // Bind Ajax behaviors to all items showing the class.
        var element_settings = {};

        // This removes any loading/progress bar on the clicked link
        // and displays the colorbox loading screen instead.
        element_settings.progress = { 'type': 'none' };
        // For anchor tags, these will go to the target of the anchor rather
        // than the usual location.
        if (href) {
            element_settings.url = link;
            element_settings.event = 'click';
        }

        $(this).click(function () {
            $this = $(this);

            // Lets extract our width and height giving priority to the data attributes.
            var innerWidth = $this.data('inner-width');
            var innerHeight = $this.data('inner-height');
            if (typeof innerWidth != 'undefined' && typeof innerHeight != 'undefined') {
                var params = $.urlDataParams(innerWidth, innerHeight);
            } else {
                var params = $.urlParams(href);
            }

            params.html = '<div id="colorboxNodeLoading"></div>';
            params.onComplete = function () {
                $this.colorboxNodeGroup();
            }
            params.open = true;

            // Launch our colorbox with the provided settings
            $(this).colorbox($.extend({}, Drupal.settings.colorbox, params));
        });

        // Log our click handler to our ajax object
        var base = $(this).attr('id');
        Drupal.ajax[base] = new Drupal.ajax(base, this, element_settings);

        // Default to auto click for manual call to this function.
        if (settings.launch) {
            Drupal.ajax[base].eventResponse(this, 'click');
            $(this).click();
        }
    }

    // Allow for grouping on links to showcase a gallery with left/right arrows.
    // This function will find the next index of each link on the page by the rel
    // and manually force a click on the link to call that AJAX and update the
    // modal window.
    $.fn.colorboxNodeGroup = function () {
        // Lets do something wonky with galleries.
        var rel = $(this).attr('rel');
        if ($('a[rel="' + rel + '"]:not("#colorbox a[rel="' + rel + '"]")').length > 1) {
            $related = $('a[rel="' + rel + '"]:not("#colorbox a[rel="' + rel + '"]")');
            var idx = $related.index($(this));
            var tot = $related.length;

            // Show our gallery buttons
            $('#cboxPrevious, #cboxNext').show();
            $.colorbox.next = function () {
                index = getIndex(1);
                $related[index].click();

            };
            $.colorbox.prev = function () {
                index = getIndex(-1);
                $related[index].click();
            };

            // Setup our current HTML
            $('#cboxCurrent').html(Drupal.settings.colorbox.current.replace('{current}', idx + 1).replace('{total}', tot)).show();

            var prefix = 'colorbox';
            // Remove Bindings and re-add
            // @TODO: There must be a better way?  If we don't remove it causes a memory to be exhausted.
            $(document).unbind('keydown.' + prefix);

            // Add Key Bindings
            $(document).bind('keydown.' + prefix, function (e) {
                var key = e.keyCode;
                if ($related[1] && !e.altKey) {
                    if (key === 37) {
                        e.preventDefault();
                        $.colorbox.prev();
                    } else if (key === 39) {
                        e.preventDefault();
                        $.colorbox.next();
                    }
                }
            });
        }

        function getIndex(increment) {
            var max = $related.length;
            var newIndex = (idx + increment) % max;
            return (newIndex < 0) ? max + newIndex : newIndex;
        }
    }

    // Utility function to parse out our width/height from our url params
    $.urlParams = function (url) {
        var p = {},
            e,
            a = /\+/g,  // Regex for replacing addition symbol with a space
            r = /([^&=]+)=?([^&]*)/g,
            d = function (s) {
                return decodeURIComponent(s.replace(a, ' '));
            },
            q = url.split('?');
        while (e = r.exec(q[1])) {
            e[1] = d(e[1]);
            e[2] = d(e[2]);
            switch (e[2].toLowerCase()) {
                case 'true':
                case 'yes':
                    e[2] = true;
                    break;
                case 'false':
                case 'no':
                    e[2] = false;
                    break;
            }
            if (e[1] == 'width') {
                e[1] = 'innerWidth';
            }
            if (e[1] == 'height') {
                e[1] = 'innerHeight';
            }
            p[e[1]] = e[2];
        }
        return p;
    };

    // Utility function to return our data attributes for width/height
    $.urlDataParams = function (innerWidth, innerHeight) {
        return {'innerWidth':innerWidth,'innerHeight':innerHeight};
    };

})(jQuery);
;
