(function($) {
	
	$(document).on('ready', function() {
		console.log('working');
	});
	
	
	
})(jQuery);;
